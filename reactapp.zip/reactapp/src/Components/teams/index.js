import React from "react";
import './index.css';

const Teams = () => {
    const teams = [
        {
            name: 'EsakiMuthu',
            logo: '../../../assets/angular.png',
            role: `FullStack Developer & Mobile App Developer`,
            position: 'CEO, Founder'
        },
        {
            name: 'VarunKumar',
            logo: '../../../assets/react.png',
            role: 'FrontEnd Developer',
            position: 'CTO, Marketing Analyst'
        }, 
        {
            name: 'Mohamed Afzal',
            logo: '../../../assets/hybrid.png',
            role: 'FrontEnd Developer',
            position: 'CTO'
        },
        {
            name: 'RaghuSelvaPraveen',
            logo: '../../../assets/ionic.png',
            role: 'BackEnd Developer',
            position: 'CTO'
        },
        {
            name: 'SuryaPrasanth',
            logo: '../../../assets/surya.png',
            role: 'FrontEnd Developer & Hybrid App Developer',
            position: 'CTO'
        }
    ]
    return(
        <div className="teams-container" id="teams">
            <h1>Our Teams</h1>
            <div className="teams-section">
                {
                    teams.map((data, key) => {
                        return(
                            <div className="teams-card" key={key}>
                                <div className="image" style={{ backgroundImage: `url(${data.logo})`}}/>
                                <div className="team-members">
                                    <div className="name">{data.name}</div>
                                    <div className="role">{data.role}</div>
                                    <div className="position">{data.position}</div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default Teams;