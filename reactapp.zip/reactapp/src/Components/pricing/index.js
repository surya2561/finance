import React from "react";
import './index.css';

const Pricing = () => {
    return(
        <div className="pricing-container">
            
        </div>
    )
}

export default Pricing;