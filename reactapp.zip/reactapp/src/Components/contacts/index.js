import React, { useState } from "react";
import './index.css';

const Contacts = () => {
    const [contact, setContact] = useState({
        name: '',
        email: '',
        phone: ''
    })

    function handleInputData(event){
        const name = event.target.name;
        const value = event.target.value;
        setContact({...contact, [name]: value});
    }

    function submitForm(event){
        event.preventDefault();
    }
    return(
        <div className="contact-container" id="contact">
            <h1>Get in touch</h1>
            <form className="form" onSubmit={(e) => submitForm(e)}>
                <div className="form-fields">
                    <input value={contact.name} color='primary' variant="outlined" type='text' id='name' name='name' placeholder='Enter your name*' onChange={(e) => handleInputData(e)}/>
                </div>
                <div className="form-fields">
                    <input value={contact.email} color='primary' variant="outlined" type='email' id='email' name='email' placeholder='Enter your mail*' onChange={(e) => handleInputData(e)}/>
                </div>
                <div className="form-fields">
                    <input value={contact.phone} color='primary' variant="outlined" type='text' id='phone' name='phone' placeholder='Enter your phonenumber*' onChange={(e) => handleInputData(e)}/>
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    )
}

export default Contacts;