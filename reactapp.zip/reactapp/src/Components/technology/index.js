import React, { useState } from "react";
import './index.css';

const Technology = () => {
    const [tech, setTech] = useState([{
        type: 'FrontEnd',
        lang: [{
            icon: '../../../assets/angular.png',
            name: 'Angular'
        },{
            icon: '../../../assets/react.png',
            name: 'React'
        }, {
            icon: '../../../assets/android.png',
            name: 'Android'
        }, {
            icon: '../../../assets/swift.png',
            name: 'Swift'
        },{
            icon: '../../../assets/react.png',
            name: 'React-Native'
        }, {
            icon: '../../../assets/ionic.png',
            name: 'Ionic'
        }]
    }, {
        type: 'BackEnd',
        lang: [{
            icon: '../../../assets/java.jpg',
            name: 'Java'
        }, {
            icon: '../../../assets/nodejs.png',
            name: 'NodeJS'
        }, {
            icon: '../../../assets/larval.png',
            name: 'Laravel'
        }]
    },{
        type: 'Database',
        lang: [{
            icon:'../../../assets/mysql.png',
            name: 'MySQL'
        }, {
            icon: '../../../assets/mongodb.png',
            name: 'MongoDB'
        }, {
            icon: '../../../assets/postgresql.png',
            name: 'Postgre SQL'
        }, {
            icon: '-../../../assets/elasticsearch.png',
            name: 'Elastic Search'
        }]
    }
])
    return(
        <div className="tech-container" id="technology">
            <h1>Technologies We Work</h1>
            <div className="tech-section">
                {
                    [...tech].map((data, key) => {
                        return(
                            <div className="tech-content" key={key} data-aos="fade-right">
                                <h3 className="tech-name">{data.type}</h3>
                                <div className="tech-type" data-aos="fade-up">
                                    {
                                        data.lang.map((item, key) => {
                                            return(
                                                <div className="tech-items" key={key} >
                                                    <div className="icon" style={{backgroundImage: `url(${item.icon})`, backgroundSize: '100% 100%', backgroundRepeat: 'no-repeat'}}></div>
                                                    <div className="name">{item.name}</div>
                                                </div>
                                            )
                                        })
                                    }
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default Technology;