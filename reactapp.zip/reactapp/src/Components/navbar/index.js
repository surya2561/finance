import React, { useEffect, useState } from 'react';
import './index.css';
import {Link} from 'react-scroll'
import {GiHamburgerMenu} from 'react-icons/gi';
import { ImCross } from 'react-icons/im';

const NavBar = () => {
    const [hamClick, setHamClick] = useState(false);
    const navItems = [
    {
        name: 'Home',
        href: 'home'
    }, {
        name: 'Services',
        href: 'services'
    }, {
        name: 'Technologies',
        href: 'technology'
    }, {
        name: 'Contact',
        href: 'contact'
    },
    // {
    //     name: 'Teams',
    //     href: 'teams',
    // },
    //  {
    //     name: 'Products',
    //     href: 'products'
    // }, {
    //     name: 'Pricing',
    //     href: 'pricing'
    // }
    ];

    useEffect(() => {
        window.addEventListener('scroll', handlescroll)
    },[]);

    const handlescroll = () => {
        let header = document.querySelector('.nav-container');
        let scrollPosition =  window.scrollY > 0;
        header.classList.toggle('scrolling-active', scrollPosition);
    }
    return(
            <div className={hamClick ? 'ham-clicked nav-container' : 'nav-container'}>
                <Link 
                    className="company-logo" 
                    to="home" 
                    offset={-70}
                    duration={1000}
                    spy={true}
                    smooth={true}
                >
                        Armsv Tech
                </Link>
                <div className='nav-items'>
                    {
                        navItems.map((item, key) => {
                            return (
                            <Link 
                                smooth={true} 
                                key={key} 
                                to={item.href} 
                                activeClass="active" 
                                offset={-70}
                                duration={1000}
                                spy={true}
                                onClick={() => setHamClick(false)}
                            >
                                <span>{item.name}</span>
                            </Link>
                            )
                        })
                    }
                </div>
                <span className="hamburger-icon" onClick={() => setHamClick(!hamClick)}>
                    {
                        !hamClick ? <GiHamburgerMenu className="icon"/> : <ImCross className="icon"/>
                    }
                </span>
            </div>
    )
}

export default NavBar;