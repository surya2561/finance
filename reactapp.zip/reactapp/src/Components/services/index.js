import React, { useState } from "react";
import './index.css';

const Services = () => {
    const services = [
    {
        logo: '../../../assets/ui.jpg',
        title: 'Interface Design',
        description: 'Attractive, interactive & visually appealing web front-end pages are crucial for the success of a business'
    },
    {
        logo: '../../../assets/android-ios.png',
        title: 'Android & IOS Apps',
        description: 'We build secure and scalable application through native technologies to enchance user experience and performance'
    },
    {
        logo: '../../../assets/hybrid.png',
        title: 'Hybrid Mobile Apps',
        description: 'We build Cost-effective, Easy Maintain apps that are written once, run everywhere in a shorter timeframe'
    },
    {
        logo: '../../../assets/sass.png',
        title: 'SASS',
        description: 'We build secure and scalable application through native technologies to enchance user experience and performance'
    },
    {
        logo: '../../../assets/web.png',
        title: 'Website & Web Apps',
        description: 'we ensure to Improve Business Credibility, Professionalize Your Brand, Expand your Market Reach and provide Efficient Ways to Promote Your Business'
    },
    {
        logo: '../../../assets/android-ios.png',
        title: 'Android & IOS Apps',
        description: 'We build secure and scalable application through native technologies to enchance user experience and performance'
    }
    ];

    return(
        <div className="services-container" id="services">
            <h1>Services We Provide</h1>
            <div className="services-content">
                {
                    services.map((data, key) => {
                        return(
                            <div className="services-card" data-aos="fade-up" key={key}>
                                <img className="logo" src={data.logo} />
                                <h3 className="title">{data.title}</h3>
                                <div className="description">{data.description}</div>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default Services;