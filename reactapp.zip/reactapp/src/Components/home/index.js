import React from "react";
import './index.css';
import { BsArrowRight } from 'react-icons/bs'
const Home = () => {
    return(
        <div className="home-container" id="home">
            <div className="left-content">
                <h1 data-aos="fade-right">Our Intelligent Technology Solutions and Services</h1>
                <div data-aos="fade-left">IT Design & Development, Delivering tailor made services & solutions for our clients, to cater to their unique business goals</div>
                <button type="button">
                    <span>Get Started</span>
                    <BsArrowRight className="arrow"/> 
                </button>
            </div>
            <div className="right-content" >
                <div className="banner-image" style={{backgroundImage: `url(https://redbee365.com/wp-content/uploads/2020/09/illustration1.png)`}}></div>
            </div>
        </div>
    )
}

export default Home;