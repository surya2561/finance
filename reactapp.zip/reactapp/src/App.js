import './App.css';
import NavBar from './Components/navbar';
import Home from './Components/home';
import Services from './Components/services';
import Technology from './Components/technology';
import Aos from 'aos';
import "aos/dist/aos.css";
import { useEffect } from 'react';
import Teams from './Components/teams';
import Contacts from './Components/contacts';

function App() {
  useEffect(() => {
    Aos.init({duration: 2000});
  }, [])

  return (
    <div className="App">
      <NavBar/>
      <div className="components">
        <Home/>
        <Services/>
        <Technology />
        {/* <Teams/> */}
        <Contacts/>
      </div>
    </div>
  );
}

export default App;
