import React from 'react';
import './index.css';
import { Route, Switch } from 'react-router';
import SignIn from '../signin';
import SignUp from '../signup';
import { Transform } from '../../utils/transform';
import { form } from '../../form';
import SideDrawer from '../sideDrawer';

const Landing = () => {
    const signInFormValues = Transform.formTransform(form.signIn);
    const signUpFormValues = Transform.formTransform(form.signUp);

    return(
        <div className="landing-container">
            <SideDrawer/>
            <div className="components">
                {/* Here you have to give the component name like exactly I mentioned below For now i just given signin signup components for checking purpose */}
                <Switch>
                    <Route path="/signin" exact>
                        <SignIn signInForm = {signInFormValues}/>
                    </Route>
                    <Route path="/signup" exact>
                        <SignUp signUpForm = {signUpFormValues}/>
                    </Route>
                </Switch>
            </div>
        </div>
    )
}

export default Landing;