import React, { useState } from 'react';
import './index.css';
import { NavLink } from 'react-router-dom';
import { MdOutlineDashboardCustomize } from 'react-icons/md';
import { BsBoxArrowInUpRight } from 'react-icons/bs';
import { CgCalendarDates } from 'react-icons/cg';
import { HiTemplate } from 'react-icons/hi';
import { AiOutlineUsergroupAdd, AiOutlineUser, AiOutlineLogout } from 'react-icons/ai';
import { MdOutlineCases, MdOpenInNew } from 'react-icons/md';
import { FiHelpCircle, FiSettings } from 'react-icons/fi';

const SideDrawer = () => {
    const menuList = [
        {icon: <MdOutlineDashboardCustomize/>, name: 'Dashboard', path:"/signin", class: 'active'},
        {icon: <BsBoxArrowInUpRight/>, name: 'Tasks', path: "/signup"},
        {icon: <CgCalendarDates/>, name: 'Calendar', path: "/calender"},
        {icon: <HiTemplate/>, name: 'Employees', path: "/employees"},
        {icon: <AiOutlineUsergroupAdd/>, name: 'Customers', path: "/customers"},
        {icon: <MdOutlineCases/>, name: 'Cases', path: "/cases"},
        {icon: <AiOutlineUser/>, name: 'Leads', path: "/user"},
        {icon: <MdOpenInNew/>, name: 'Requests', path: "/request"},
    ];
    const menuFooterList = [
        {icon: <FiSettings/>, name: 'Settings', path: "/settings"},
        {icon: <FiHelpCircle/>, name: 'Help', path: "/help"}
    ];

    const bottom = [
        {icon: <AiOutlineLogout/>, name: 'Logout', path: "/logout"}
    ]
    
    return(
        <div className="sideDrawer-container">
                <div className="sideDrawer-header">Finance</div>
                <hr/>
                <div className="sideDrawer-menu-header">
                    {
                        menuList.map((data) => {
                            return(
                                <div className="menu-list">
                                    <NavLink to={data.path} activeClassName={data.class}>
                                        <div className="sideDrawer-icon">{data.icon}</div>
                                        <div className="sideDrawer-menu-name">{data.name}</div>
                                    </NavLink>
                                </div>
                            )
                        })
                    }
                </div>
                <div className="sideDrawer-menu-footer">
                    {
                        menuFooterList.map((data) => {
                            return(
                                <div className="menu-list">
                                    <NavLink to={data.path}>
                                        <div className="sideDrawer-icon">{data.icon}</div>
                                        <div className="sideDrawer-menu-name">{data.name}</div>
                                    </NavLink>
                                </div>
                            )
                        })
                    }
                </div>
                <div className="sideDrawer-menu-bottom">
                    {
                        bottom.map((data) => {
                            return(
                                <div className="menu-list">
                                     <NavLink to={data.path}>
                                        <div className="sideDrawer-icon">{data.icon}</div>
                                        <div className="sideDrawer-menu-name">{data.name}</div>
                                    </NavLink>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
    )
}

export default SideDrawer;