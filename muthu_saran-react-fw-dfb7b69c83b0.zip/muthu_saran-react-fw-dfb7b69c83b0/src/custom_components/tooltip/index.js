import { Tooltip } from '@material-ui/core';
import React from 'react';

const ToolTip = (props) => {
    return(
        <Tooltip {...props}>
            {props.children}
        </Tooltip>
    )
}

export default ToolTip;