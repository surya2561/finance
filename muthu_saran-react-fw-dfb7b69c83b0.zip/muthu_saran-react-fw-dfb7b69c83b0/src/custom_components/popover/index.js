import * as React from 'react';
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';

export default function BasicPopover(props) {
    const [anchorEl, setAnchorEl] = React.useState(props.anchorEl ? props.anchorEl : false);
  
    const handleClose = () => {
      setAnchorEl(null);
    };
  
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;
  
    return (
      <>
        <Popover
          id={id}
          open={open}
          onClose={handleClose}
          {...props}
        >
          <Typography sx={{ p: props.size }}>{props.message}</Typography>
        </Popover>
      </>
    );
  }