import React from 'react';
import {TextField, makeStyles} from '@material-ui/core';
import './index.css';

const useStyles = makeStyles({
    textbox: {
        width: "100%"
    }
})

const TextBox = (props) => {
    const classes = useStyles();
    return(
        <>
             <TextField className={classes.textbox} color="primary" {...props}/>
        </>
    )
}

export default TextBox;