import React from 'react';
import { RadioGroup, FormControlLabel, Radio, makeStyles } from '@material-ui/core';
import './index.css';

const useStyles = makeStyles({
    horizontal: {
        flexDirection: 'row'
    },
    vertical: {
        flexDirection: 'column'
    }
})


const RadioButton = ({list, direction, label, onChange, defaultValue, name}) => {
    const classes = useStyles();
    return (
        <div>
            <label>
                {label}
            </label>
            <RadioGroup name={name} id={name} value={defaultValue} className={direction && direction == 'horizontal' ? classes.horizontal : classes.vertical}>
            {
                    [...list].map((item, key) => {
                        return (
                            <FormControlLabel value={item.value} control={<Radio color="primary"/>} label={item.label} key={key} onChange={(e) => onChange(e)}/>
                        )
                    })
                }
            </RadioGroup>
        </div>
    )
}

export default RadioButton;