import React from 'react';
import './index.css';
import { Select, FormControl, makeStyles } from '@material-ui/core';

const useStyles = makeStyles({
    select: {
        width: "100%"
    }
})

const Dropdown = ({list, onValueChange, name}) => {
    const classes = useStyles();
    return(
        <>
            <FormControl variant="outlined" className={classes.select}>
                <Select native name={name} id={name} onChange={(e) => onValueChange(e)}>
                    {
                        [...list].map((item, key) => {
                            return (
                                <option key={key} value={item.value} name={name} >{item.label}</option>
                            )
                        })
                    }
                </Select>
            </FormControl>
        </>
    )
}

export default Dropdown;