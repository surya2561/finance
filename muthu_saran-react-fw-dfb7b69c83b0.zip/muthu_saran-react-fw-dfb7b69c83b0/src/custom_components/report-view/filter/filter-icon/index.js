import React from 'react';
import './index.css';
import { MdFilterAlt } from 'react-icons/md';

const FilterIcon = (props) => {
    return(
    <MdFilterAlt className="filter-icon" onClick={() => props.clicked()}/>
    )
}

export default FilterIcon;