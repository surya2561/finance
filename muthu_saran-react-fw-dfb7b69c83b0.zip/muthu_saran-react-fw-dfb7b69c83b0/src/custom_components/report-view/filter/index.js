import React, { useState } from 'react';
import './index.css';

const Filter = () => {
    return(
        <div className="filter">
            Filter Clicked
        </div>
    )
}

export default Filter;