import React from 'react';
import { IoMdSearch } from 'react-icons/io';
import './index.css';

const Input = (props) => {

    let inputValues = {};

    const handleEnterKeyPress = () => {
        document.querySelectorAll('input').forEach((input)=> {
            if(input.value !== '') {
                inputValues = { ...inputValues, [input.name]: input.value }
            }
        })
        props.fetchData({search: inputValues})
    }
    
    return(
        <div className="table-input" style={props.isSearchEnabled ? {visibility: 'visible'} : {visibility: 'hidden'}}>
            <input type="text" placeholder={`Search by ${props.displayName}`} id={`${props.id}`} name={props.columnName} onKeyDown={(e) => e.key === 'Enter' && handleEnterKeyPress(e, props.columnName)}/>
            <IoMdSearch className="search-icon"/>
        </div>
    )
}

export default Input;