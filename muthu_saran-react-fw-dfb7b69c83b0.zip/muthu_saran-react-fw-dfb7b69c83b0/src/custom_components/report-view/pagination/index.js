import React, { useState } from 'react';
import './index.css';
import { MdKeyboardArrowLeft, MdKeyboardArrowRight, MdFilterListAlt } from 'react-icons/md';
import Select from '../select/index';

const Pagination = (props) => {

    const [pagination, setPagination] = useState({...props.pagination, lastPage: false});
    const [optionValue, setOptionValue] = useState(10);

    const changePagination = (action) => {
        let { showItemsPerPage,totalItems, startIndex, endIndex, lastPage } = {...pagination};
        let updatedPaginationValues = {...pagination};
        if(action === 'prev') {
            updatedPaginationValues = {
                ...updatedPaginationValues, 
                startIndex: startIndex - showItemsPerPage,
                endIndex: endIndex - showItemsPerPage + (lastPage ? totalItems % 10 !== 0 ? Math.floor(10 - totalItems%10) : 0 : 0),
                lastPage: false
            }
        } else {
            updatedPaginationValues = {
                ...updatedPaginationValues, 
                startIndex: startIndex + showItemsPerPage,
                endIndex: (endIndex + showItemsPerPage) > totalItems ? totalItems : endIndex + showItemsPerPage,
                lastPage: (endIndex + showItemsPerPage) > totalItems ? true : false
            }
        }
        setPagination(updatedPaginationValues);
        props.fetchData({pagination : updatedPaginationValues});
    }

    const changePageCount = (value) => {
        setOptionValue(value);
        setPagination({...pagination, showItemsPerPage: value, endIndex: value > pagination.totalItems ? pagination.totalItems : value, startIndex: 1})
    }

    return(
        <div className="pagination-container">
            <div className="pagination">
                <div className="dropdown">
                    <span>Rows per page :</span>
                    <Select options={props.paginationOptions} onchange={(value) => changePageCount(value)} value={optionValue}/>
                </div>
                <div className="content">
                    <span className="startIndex">{pagination.startIndex}</span>
                    <span> - </span>
                    <span className="endIndex">{pagination.endIndex}</span>
                    <span> of </span>
                    <span className="totalItems">{pagination.totalItems}</span>
                </div>
                <div className="icons">
                    <MdKeyboardArrowLeft className={`arrow ${pagination.startIndex === 1 ? 'disabled' : ''}`} onClick={() => changePagination('prev')}/>
                    <MdKeyboardArrowRight className={`arrow ${((pagination.totalItems / pagination.endIndex === 1)|| (pagination.endIndex >= pagination.totalItems)) ? 'disabled' : ''}`} onClick={() => changePagination('next')}/>
                </div>
            </div>
        </div>
    )
}

export default Pagination;