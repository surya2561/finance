import React, { useState } from 'react';
import { IoMdArrowDropdown } from 'react-icons/io';
import { BsFillCaretDownFill } from 'react-icons/bs';
import './index.css';
import { Scrollbars } from 'react-custom-scrollbars';
import Input from '../input';

const Table = (props) => {

    const toggleSort = (columnId) => {
        const tableContent = [...props.tableData.content];
        for(let x in tableContent){
            if(tableContent[x].columnId === columnId){
                const tableConfig = props.tableData.tableConfig;
                const sort = {
                    ...tableConfig.sort, 
                    sortColumn: tableContent[x].columnName, 
                    sortOrder: tableContent[x].sortOrder === 'ASC' ? 'DESC' : 'ASC',
                }
                props.fetchData({sort: sort});
                break;
            }
        }
    }

    const renderTableHeader = () => {
        return [...props.tableData['content']].map((attr) => {
            return(
                <th key={'th ' + attr.columnId}>
                    <div className="header">
                        <span>{attr.displayName}</span>
                        {
                            attr.isSortEnabled ?
                            <span className="icon" onClick={() => attr.isSortEnabled && toggleSort(attr.columnId)}>
                                <BsFillCaretDownFill className={attr.sortOrder === 'DESC' ? "arrow-up" : "arrow-down"}/>
                            </span>
                            : ''
                        }
                    </div>
                </th>
            )
        })
    }

    const renderTableRows = () => {
        return props.tableData['content'].map((data, key) => {
            return(
                <td key={'td ' + data.columnId}>
                    {
                         props.search ? 
                         <Input isSearchEnabled = {data.isSearchEnabled} displayName={data.displayName} id={key} columnName={data.columnName} fetchData={props.fetchData}/> : 
                         ''
                    }
                    {data.values.map((val, key) => {
                        return <div key={'tr ' + key} className="tr">{val}</div>
                    })}
                </td>
            )
        })
    }
    
    return(
        <Scrollbars style={{ width: '100%', height: '100vh' }}>
            <div className="table">
                <table id="report">
                    <thead>
                        {renderTableHeader()}
                    </thead>
                    <tbody>
                        {renderTableRows()}
                    </tbody>
                </table>
            </div>
        </Scrollbars>
    )
}

export default Table;