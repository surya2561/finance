import React, { useState } from 'react';
import './index.css';
import { MdArrowDropDown, MdArrowDropUp } from 'react-icons/md';

const Options = (props) => {
    const options = props.options;
    return(
        <div className="options">
            {
                options.map((data) => {
                    return <span key={'opt ' + data.id} onClick={() => props.valueChange(data.value)}>{data.value}</span>
                })
            }
        </div>
    )
}

export default Options;