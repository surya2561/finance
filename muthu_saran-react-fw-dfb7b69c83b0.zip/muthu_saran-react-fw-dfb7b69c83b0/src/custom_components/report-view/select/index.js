import React, { useState } from 'react';
import { MdArrowDropDown, MdArrowDropUp } from 'react-icons/md';
import { BsFillCaretUpFill, BsFillCaretDownFill } from 'react-icons/bs';
import './index.css';
import Options from './options';

const Select = (props) => {
    const [dropdownClicked, setDropDownClicked] = useState(false);
    return(
        <div className="select">
            <button onClick={() => setDropDownClicked(!dropdownClicked)}>
                <span>{props.value}</span>
                <div className="arrow-icon">
                    <BsFillCaretUpFill/>
                    <BsFillCaretDownFill/>
                </div>
            </button>
            {
                dropdownClicked && <Options options={props.options} valueChange = {(value) => (setDropDownClicked(false), props.onchange(Number(value)))}/>
            }
        </div>
    )
}

export default Select;