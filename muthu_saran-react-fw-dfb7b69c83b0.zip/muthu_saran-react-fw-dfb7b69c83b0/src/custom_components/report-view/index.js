import React, { useState } from 'react';
import './index.css';
import Pagination from './pagination/index';
import Table from './table/index';
import Search from './search';
import Filter from './filter';
import FilterIcon from './filter/filter-icon';

const ReportView = () => {
    const [search, setSearch] = useState(false);
    const [filterClicked, setFilterClicked] = useState(false);
    const paginationOptions = [
        { id: 1, value: '10' },
        { id: 2, value: '20' },
        { id: 3, value: '50' },
        { id: 4, value: '100' }
    ]
    const [table, setTable] = useState({
        tableConfig: {
            pagination: {
                showItemsPerPage: 10,
                totalItems: 92,
                startIndex: 1,
                endIndex: 10
            }
        },
        content: [{
            "columnId": 1,
            "columnName": "first_name",
            "displayName": "First name",
            "isSearchEnabled": true,
            "isSortEnabled": true,
            "sortOrder": 'ASC',
            "values": ['Surya', 'Prasanth', 'Varun', 'Kumar', 'Esakki', 'Muthu', 'Raghu', 'Selva', 'Praveen', 'Surya', 'Prasanth', 'Varun', 'Kumar', 'Esakki', 'Muthu', 'Raghu', 'Selva', 'Praveen'],
            "toggle": false
        }, {

            "columnId":2,
            "columnName": "last_name",
            "displayName": "Last name",
            "isSearchEnabled": true,
            "isSortEnabled": true,
            "sortOrder": 'ASC',
            "values": ['S', 'P', 'V', 'K', 'E', 'M', 'R', 'S', 'P','S', 'P', 'V', 'K', 'E', 'M', 'R', 'S', 'P'],
            "toggle": false
        }, {
            "columnId":3,
            "columnName": "email",
            "displayName": "Email",
            "isSearchEnabled": true,
            "isSortEnabled": false,
            "sortOrder": 'ASC',
            "values": ['S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com','S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com'],
            "toggle" : false
        },{
            "columnId":3,
            "columnName": "email",
            "displayName": "Email",
            "isSearchEnabled": true,
            "isSortEnabled": false,
            "values": ['S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com','S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com'],
            "toggle" : false
        },{
            "columnId":3,
            "columnName": "email",
            "displayName": "Email",
            "isSearchEnabled": true,
            "isSortEnabled": false,
            "values": ['S@gmail.com', '-', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com','S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com'],
            "toggle" : false
        },{
            "columnId":3,
            "columnName": "email",
            "displayName": "Email",
            "isSearchEnabled": false,
            "isSortEnabled": false,
            "values": ['S@gmail.com', 'Pksdjfksdfkdjhfkdfjhgkdhfkdkjhkdj@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com','S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com'],
            "toggle" : false
        },{
            "columnId":3,
            "columnName": "email",
            "displayName": "Email",
            "isSearchEnabled": false,
            "isSortEnabled": false,
            "values": ['S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com','S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com'],
            "toggle" : false
        },{
            "columnId":3,
            "columnName": "email",
            "displayName": "Email",
            "isSearchEnabled": false,
            "isSortEnabled": false,
            "values": ['S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com','S@gmail.com', 'P@gmail.com', 'V@gmail.com', 'K@gmail.com', 'E@gmail.com', 'M@gmail.com', 'R@gmail.com', 'S@gmail.com', 'P@gmail.com'],
            "toggle" : false
        }],
    });

    const fetchData = (requestData) => {
        const queryParams = 'http://localhost:3000/api/reportData';
        // setTable(requestData);
        console.log(requestData);
    }

    return(
        <div className="report">
            <div className="top">
                <Search onchangesearch = {() => setSearch(!search)} search={search}/>
                <Pagination pagination={table.tableConfig.pagination} paginationOptions={paginationOptions} fetchData={fetchData}/>
                <FilterIcon clicked = {() => setFilterClicked(!filterClicked)}/>
            </div>
            {
                filterClicked && <Filter/>
            }
            <Table tableData={table} search={search} fetchData={fetchData}/>
        </div>
    )
}

export default ReportView;