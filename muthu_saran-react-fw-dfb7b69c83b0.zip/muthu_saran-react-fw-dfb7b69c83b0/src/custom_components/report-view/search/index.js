import React from 'react';
// import { IoMdSearch } from 'react-icons/io';
import { MdClear, MdSearch } from 'react-icons/md';
import './index.css';

const Search = (props) => {
    return(
        <div className="search">
            {
                !props.search ? 
                <MdSearch className="icon" onClick={() => props.onchangesearch()}/> :
                <MdClear className="icon" onClick={() => props.onchangesearch()}/>
            }
        <span>Search</span>
        </div>
    )
}

export default Search;