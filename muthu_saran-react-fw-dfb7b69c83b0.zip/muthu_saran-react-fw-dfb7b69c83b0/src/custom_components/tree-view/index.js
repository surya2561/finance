import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TreeView from '@material-ui/lab/TreeView';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import TreeItem from '@material-ui/lab/TreeItem';

const useStyles = makeStyles({
    root: {
      height: '100%',
      flexGrow: 1,
      maxWidth: '100%',
    },
  });

  const Tree_View = ({data}) => {
    const classes = useStyles();
    const renderTree = (nodes) => {
        let set = new Set([]);
        return(
           <TreeItem key={nodes.id} nodeId={String(nodes.id)} label={nodes.name}>
               {
                     Object.keys(nodes).map((key) => {
                          if(Array.isArray(nodes[key]) || typeof(nodes[key]) === 'object'){
                               set.add(key);
                          }
                     }),
                     set.size > 0 ? [...set].map(val => Array.isArray(nodes[val]) ? nodes[val].map((node) => renderTree(node)) : renderTree(nodes[val])) : null
               }
           </TreeItem>
        )
      };

   return (
    <TreeView
      className={classes.root}
      defaultCollapseIcon={<ExpandMoreIcon />}
      defaultExpanded={['root']}
      defaultExpandIcon={<ChevronRightIcon />}
    >
      {
            [...data].map(value => {
                return renderTree(value);
            })
        }
    </TreeView>
  );
}

export default Tree_View;
