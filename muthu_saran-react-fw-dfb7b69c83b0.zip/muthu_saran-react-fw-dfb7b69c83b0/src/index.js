import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import TopNavBar from './custom_components/topnavbar';
import TextBox from './custom_components/textbox';
import RadioButton from './custom_components/radioButton';
import Dropdown from './custom_components/dropdown';
import Table from './custom_components/table';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Tree_View from './custom_components/tree-view';
import GraphView from './custom_components/graphView';
import ToolTip from './custom_components/tooltip';
import Model from './custom_components/model';
import AlertMessage from './custom_components/alert';
import BasicPopover from './custom_components/popover';
import ReportView from './custom_components/report-view';

const array =[
      {title:"home",path:"/home"},
      {title:"help",path:'/path'}
  ], radiobutton = [
    {label: "Female", value: "female", checked: true},
    { label: "Male", value: "male"},
    { label: "Others", value: "others"}
  ],
  dropdownValues = [
    {label: "Ten", value: 10},
    {label: "Twenty", value: 20},
    {label: "Thirty", value: 30},
    {label: "Forty", value: 40},
    
  ],
    rows = [
    { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
    { id: 2, lastName: 'Lannister', firstName: 'Cersei', age: 42 },
    { id: 3, lastName: 'Lannister', firstName: 'Jaime', age: 45 },
    { id: 4, lastName: 'Stark', firstName: 'Arya', age: 16 },
    { id: 5, lastName: 'Targaryen', firstName: 'Daenerys', age: null },
    { id: 6, lastName: 'Melisandre', firstName: null, age: 150 },
    { id: 7, lastName: 'Clifford', firstName: 'Ferrara', age: 44 },
    { id: 8, lastName: 'Frances', firstName: 'Rossini', age: 36 },
    { id: 9, lastName: 'Roxie', firstName: 'Harvey', age: 65 },
    { id: 10, lastName: 'Snow', firstName: 'Jon', age: 35 },
    { id: 11, lastName: 'Lannister', firstName: 'Cersei', age: 42 },
    { id: 13, lastName: 'Lannister', firstName: 'Jaime', age: 45 },
    { id: 14, lastName: 'Stark', firstName: 'Arya', age: 16 },
    { id: 15, lastName: 'Targaryen', firstName: 'Daenerys', age: null },
    { id: 16, lastName: 'Melisandre', firstName: null, age: 150 },
    { id: 17, lastName: 'Clifford', firstName: 'Ferrara', age: 44 },
    { id: 18, lastName: 'Frances', firstName: 'Rossini', age: 36 },
    { id: 19, lastName: 'Roxie', firstName: 'Harvey', age: 65 },
  ],
  data = [{
    id: '1',
    name: "Applications",
    type: [
      {
        id: 2,
        name: "calender",
        variant: {
          id: 4,
          name: 'google'
        }
      },
      {
        id: 3,
        name: "Chrome"
      }
    ]
  }]
  ;

  const columnSchema = [
    { field: 'id', headerName: 'ID', width: 100},
    {
      field: 'firstName',
      headerName: 'First name',
      editable: false,
      width: 200
    },
    {
      field: 'lastName',
      headerName: 'Last name',
      editable: false,
      width: 200
    },
    {
      field: 'age',
      headerName: 'Age',
      editable: false,
      width:150,
      filterable: false
    },
    {
      field: 'fullName',
      headerName: 'Full name',
      description: 'This column has a value getter and is not sortable.',
      width:200,
      valueGetter: (params) =>
        `${params.getValue(params.id, 'firstName') || ''} ${
          params.getValue(params.id, 'lastName') || ''
        }`,
    },
  ];

  const onInputChange = (e) => {
    console.log('event', e);
    // console.log(e.target.value);
  }

  const onSelectChange = (e) => {
    console.log(e.target.name, e.target.id, e.target.value);
  }

  const onStateChange = function (checked) {
    console.log("checked", checked);
  };

  var timeSeriesData = [{
    name: 'Total Views',
    data: [ 4,3,10,9,29,19,25,9,12,7,19,5,13,9,17,2,7,5 ]
  }];

  var timeSeriesOptions = {
    chart: {
        type: 'line',
        height: 300,
        foreColor: "#999",
        stacked: true,
        dropShadow: {
          enabled: true,
          enabledSeries: [0],
          top: -2,
          left: 2,
          blur: 5,
          opacity: 0.06
        },
    },
    colors: ['#00E396', 'blue'],
      stroke: {
        curve: "smooth",
        width: 3
      },
        dataLabels: {
          enabled: false
        },
        markers: {
            size: 0,
            strokeColor: "#fff",
            strokeWidth: 3,
            strokeOpacity: 1,
            fillOpacity: 1,
            hover: {
              size: 6
            }
          },
        title: {
          text: 'Stock Price Movement',
          align: 'left'
        },
        fill: {
          type: 'gradient',
          gradient: {
            shadeIntensity: 1,
            inverseColors: false,
            opacityFrom: 0.5,
            opacityTo: 0,
            stops: [0, 90, 100]
          },
        },
        yaxis: {
            labels: {
              offsetX: 14,
              offsetY: -5
            },
            tooltip: {
              enabled: true
            }
          },
        xaxis: {
          type: 'datetime',
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          }
        },
        tooltip: {
            x: {
                format: "dd MMM yyyy"
              },
        },
        legend: {
            position: 'bottom',
            horizontalAlign: 'left'
          },
          fill: {
            type: "solid",
            fillOpacity: 0.7
          }
  }

  var barData = [{
    name: 'series-1',
    data: [30, 40, 35, 50, 49, 60, 70, 91, 125]
  }]
  
  var pieData = [30, 40, 35, 50, 49, 60, 70, 91, 125];

  var barOptions = {  
    labels: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999],  
    chart: {      
      id: 'apexchart-example'    
    }
  }

  var graphData = [{
    data: [44, 55, 41, 64, 22, 43, 21]
  }, {
    data: [53, 32, 33, 52, 13, 44, 32]
  }];

  var optionsBar = {
    plotOptions: {
      bar: {
        horizontal: false,
        dataLabels: {
          position: 'none',
        },
      }
    },
    dataLabels: {
      enabled: false,
     
    },
    stroke: {
      show: false,
      width: 0,
      colors: ['#fff']
    },
    tooltip: {
      shared: true,
      intersect: false
    },
    xaxis: {
      categories: [2001, 2002, 2003, 2004, 2005, 2006, 2007]
    },
    legend: {
      position: 'top',
      fontSize: '14px',
      fontFamily: 'Helvetica, Arial',
      fontWeight: 400
    }
  };


  let anchorOrigin = {
    vertical: "bottom",
    horizontal: "left"
  }

  let transformOrigin = {
    vertical: "top",
    horizontal: "center"
  }

  
ReactDOM.render(
  <React.StrictMode>
    <Router>
      {/* <TopNavBar list={array}/>
      <TextBox label="Email" id="name" variant="outlined" type="email" size="medium" color="primary" onChange={onInputChange} placeholder="Enter mail"/>
      <TextBox label="Password" variant="outlined" type="password" color="secondary" onChange={onInputChange} placeholder="Enter a Password"/>

      <RadioButton list={radiobutton} defaultValue="female" onChange={onStateChange} direction="vertical" label="gender" name="radio"/>
      <Dropdown list={dropdownValues} onValueChange={onSelectChange} name="radio"/> */}
      {/* <Table list={rows} columnSchema={columnSchema} pagination = {{rowOptions : [5, 10,20] }}/> */}
      {/* <  */}
                
      {/* <Tree_View data={data}/>
      <ToolTip title="Enter" placement="right" arrow={true}>
      <div>
      <button>Enter</button>

      </div> */}
      {/* </ToolTip> */}
      {/* <GraphView graphData={timeSeriesData} options={timeSeriesOptions} type="line" height="500"/> */}
      {/* <GraphView graphData={graphData} options={optionsBar} type="bar" height="500"/> */}
      {/* <Model show={true} title="Graph" size={{width: 500, height: 400}} offset={{left:0, top:0}} direction="up" maxWidth="sm" text="Render the graph"><GraphView graphData={graphData} options={optionsBar} type="bar" height="500"/></Model>
      <AlertMessage message="This is an error alert — check it out!" variant="filled" severity="error"/> */}
      {/* <Table 
        rows={rows} 
        columns={columnSchema} 
        onSelectionModelChange={(ids) => {
          const selectedRowData = rows.filter((row) => {
            return row.id === ids[0]
          });
            console.log("selectedRowData", selectedRowData);
          }}
        /> */}
      
      {/* <BasicPopover
        anchorOrigin = {anchorOrigin}
        transformOrigin = {transformOrigin}
        anchorEl = {true}
        size = {2}
        message="Content of popover"/> */}

      {/* <div style={{height: '100%'}}>
          <Switch>
              <Route path="/home" exact />
              <Route path="/path" exact />
          </Switch>
      </div> */}
      <ReportView/>
     </Router>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
