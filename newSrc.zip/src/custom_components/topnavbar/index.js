/*
    props :
    active - string
    list - array of objects sample = [{title : "example", path : "/example"}]
*/
import React from 'react';
import { NavLink } from 'react-router-dom';
import "./index.css";
class TopNavBar extends React.Component {
    constructor(props) {
        super(props);
        const active =  this.props.active? this.props.active :this.props.list[0].title;
        this.state = {
            active
        };
    }
    render() {
        const setStates = function(title) {
            this.setState({
                active: title
            });
        }.bind(this);
        return  <nav className="nav">
                {this.props.list.map((item,index) => {
                   return <NavLink 
                   onClick={() => setStates(item.title)}
                   className={this.state.active===item.title?'navItem activeItem':'navItem'} 
                   to={item.path}
                   key={index}>
                       <span>{item.title}</span>
                    </NavLink>
                })}
            </nav>
        
    };
}
export default TopNavBar;