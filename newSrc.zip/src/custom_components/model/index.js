import * as React from 'react';
import Button from '@mui/material/Button';
import './index.css';
import Slide from '@mui/material/Slide';
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, makeStyles } from '@material-ui/core';


const TransitionComponent = (userProps, transProps) => {
    return <Slide direction={userProps.direction} {...transProps} />
}

export default function Model(props) {
    const [open, setOpen] = React.useState(props.show);
    const handleClose = () => {
      setOpen(false);
    };
    const classes = makeStyles(theme => ({
      dialogWrapper: {
        position: 'absolute',
        height: props.size && props.size.height,
        width: props.size && props.size.width,
        left: theme.spacing(props.offset && props.offset.left),
        right: theme.spacing(props.offset && props.offset.right),
        top: theme.spacing(props.offset && props.offset.top),
        bottom: theme.spacing(props.offset && props.offset.bottom)
      }
    }))();
    
    return (
      <>
        <Dialog classes={{ paper: classes.dialogWrapper }} TransitionComponent={props.direction && TransitionComponent.bind(this, props)} fullWidth={true} maxWidth={props.maxWidth} open={open} onClose={handleClose}>
            <DialogTitle className="header-name">{props.title}</DialogTitle>
            <DialogContent dividers>
                <DialogContentText>
                  {props.text}
                </DialogContentText>
                  {props.children}
            </DialogContent>
            <DialogActions>
                <Button variant="outlined" onClick={handleClose}>Cancel</Button>
            </DialogActions>
        </Dialog>
      </>
    );
  }
  