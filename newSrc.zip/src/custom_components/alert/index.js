import * as React from 'react';
import Alert from '@mui/material/Alert';
import './index.css';
import { makeStyles } from '@material-ui/core';
import {IoMdClose} from 'react-icons/io';

const useStyles = makeStyles({
    font: {
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif !important",
        fontSize: "15px"
    },
    width: {
        width: '100%'
    }
})

export default function AlertMessage({ message, variant, severity }){
    const classes = useStyles();
    const [open, setOpen] = React.useState(true);

    const handleClose = () => {
      setOpen(false);
    };
    
    return(
        <>
            {
                open && 
                <div className="alert-container">
                    <Alert className={classes.width, classes.font} variant={variant} severity={severity}>
                        {message}
                    </Alert>
                    <IoMdClose className="icon" onClick={() => handleClose()}/>
                </div>
            }
        </>
    )
}