import React from 'react';
import './index.css';
import { DataGrid } from '@material-ui/data-grid';

function Table(props) {
     return (
        <div style={{ height: (props.tableHeight ? props.tableHeight : 500) + 'px'}} className={!props.pagination ? 'data-grid' : null}>
            <DataGrid {...props}/>
        </div>
    )
}

export default Table;