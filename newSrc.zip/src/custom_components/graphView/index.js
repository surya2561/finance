import React from 'react';
import './index.css';
import ReactApexCharts from 'react-apexcharts'

const generateDayWiseTimeSeries = (values) => {
    var i = 0;
    var series = [];
    var x = new Date().getTime();
    while (i < values.length) {
        series = [...series, [x, values[i]]];
        x += 86400000;
        i++;
    }
    return series;
}

const GraphView = ({ graphData, options, type, width = "100%", height = "100%" }) => {
    
    if (type === 'area' || type === 'line') {
        var series = [];
        graphData.forEach(item => {
            series.push({
                name: item.name,
                data: generateDayWiseTimeSeries(item.data)
            })
        });
    }

    return (
        <>
            <ReactApexCharts
                options={options}
                series={series ? series : graphData}
                type={type}
                height={height}
                width={width}
            />
        </>
    )

}

export default GraphView;


